# Design System Strategy: The Academic Ethereal

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Digital Sanctuary."** Unlike traditional academic tools that feel rigid and utilitarian, this system treats the interface as a calm, focused environment for thought. It moves away from the "grid-of-boxes" template, instead utilizing **glassmorphism, intentional asymmetry, and tonal depth** to create a high-end editorial experience.

By layering semi-transparent surfaces over a deep, shifting indigo-to-purple cosmos, we create a sense of infinite intellectual space. The goal is to make the student feel focused, not overwhelmed, using moderate roundedness and "breathing" layouts to soften the complexity of AI-driven data.

---

## 2. Colors & Surface Philosophy
The palette is rooted in the depth of `surface` (#777681) and the energy of `secondary` (#7170b6). 

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning. Structural boundaries must be defined solely through background color shifts or tonal transitions.
*   **Example:** A side navigation panel should not have a border; it should be a `surface-container-low` slab sitting against a `surface` background.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers of frosted glass.
*   **Base:** `surface` (#777681)
*   **Layout Sections:** `surface-container-low` (#7b7a86)
*   **Interactive Cards:** `surface-container` (#807f8b)
*   **Floating Modals/Popovers:** `surface-container-highest` (#8c8b93) with a 20px backdrop-blur.

### The "Glass & Gradient" Rule
To achieve "soul" in the UI, use gradients for high-impact moments.
*   **Backgrounds:** A linear gradient from `surface` to `surface-bright` (#94939a) at a 135-degree angle.
*   **CTAs:** A gradient from `primary` (#6760fd) to `secondary` (#7170b6) creates a vibrant, modern focal point that flat colors cannot replicate.

---

## 3. Typography
The typographic system balances the technical precision of **Inter** with the editorial character of **Manrope**.

*   **Display & Headlines (Manrope):** These are the "voice" of the AI. Use `display-lg` (3.5rem) with tighter tracking (-0.02em) for hero moments. The generous curves of Manrope reflect the `xl` (3rem) corner radius of the UI.
*   **Body (Inter):** For high-density academic reading. `body-lg` (1rem) is the standard for chat bubbles to ensure maximum legibility.
*   **Labels (Plus Jakarta Sans):** Used for micro-copy and metadata. This adds a third "technical" layer to the system, making the UI feel like a sophisticated instrument.

---

## 4. Elevation & Depth
We eschew traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Depth is achieved by "stacking" tiers. Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift.
*   **Ambient Shadows:** For floating glass elements, use a shadow with a 40px blur, 0px offset, and 6% opacity using the `on-surface` color. This mimics natural light diffusion rather than a digital "drop shadow."
*   **The "Ghost Border" Fallback:** If a container requires more definition against a complex background, use a 1px stroke of `outline-variant` (#a9a8b1) at **15% opacity**. Never use 100% opaque borders.
*   **Glassmorphism:** All floating containers (chat inputs, tooltips) must use `surface-container-high` at 80% opacity with a `blur(12px)` backdrop filter.

---

## 5. Components

### Chat Bubbles (The Core Experience)
*   **AI Response:** `surface-container-highest` with `md` (1.5rem) corner radius. The bottom-left corner should be `sm` (0.5rem) to indicate the "tail."
*   **User Input:** `primary-container` (#908bfa) with `on-primary-container` text. This provides high-contrast "crisp white/blue" requested for readability.

### Buttons
*   **Primary:** A gradient of `primary` to `primary-dim`. Radius: `full` (pill-shaped). No shadow.
*   **Secondary:** `surface-bright` background with `on-surface` text. 
*   **Tertiary:** Transparent background, `primary` text, no border.

### Input Fields
*   **Styling:** Use `surface-container-low`. Instead of a bottom line, use a subtle `surface-variant` background shift on hover.
*   **Corner Radius:** `lg` (2rem) for a soft, approachable feel.

### Academic Cards
*   **Constraint:** Forbid the use of divider lines. Use `spacing-8` (2rem) of vertical whitespace to separate header from body text. Use `surface-container-lowest` for the inner content area to create a "recessed" look.

---

## 6. Do’s and Don’ts

### Do
*   **Use Asymmetry:** Place the main chat stream slightly off-center to create a modern, editorial rhythm.
*   **Embrace Large Radii:** Stick to `xl` (3rem) for main containers to reinforce the "soft" professional aesthetic.
*   **Layer Colors:** Use `tertiary` (#a54100) sparingly for "Success" states or highlights to keep the palette sophisticated.

### Don't
*   **Don't use pure black:** Use `surface-container-lowest` (#777681) only for the deepest wells of depth, never as a general background.
*   **Don't use 100% opacity for overlays:** Always use the "Glass" rule for modals to maintain the sense of environmental depth.
*   **Don't use standard "Material" shadows:** Avoid small, dark, high-opacity shadows that make the UI look "heavy" or dated.